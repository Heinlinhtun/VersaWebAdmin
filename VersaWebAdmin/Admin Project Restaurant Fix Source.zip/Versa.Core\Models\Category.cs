﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Versa.Core.Models
{
    public class Category
    {
        public int CategoryId { get; set; }
        public string CategoryName { get; set; }
    }
}
